<footer class="app-footer">
	© 2017 e-genset
	<!-- <span class="float-right">Powered by <a href="http://coreui.io">CoreUI</a> -->
	<!-- </span> -->
</footer>
	