<p>Kepada Yth.</p>
<p>{{ $data->customer_name }}</p>
<p>di tempat</p>
<br>
<p>Berikut kami lampirkan Daftar Pemakaian Alat Genset dan Penunjangnya Untuk Kegiatan Refeer Container dengan nomor invoice {{ $data->invoice_no }} Periode tanggal {{ $data->start_date }} s.d tanggal {{ $data->end_date }}.</p>
<br>
<p>Terimakasih.</p>
