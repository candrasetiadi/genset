<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">

		table,  th,  td {
		    border: 1px solid black;
		    border-collapse: collapse;
		}
	</style>
</head>
<body>
	<h4 align="center">LAPORAN HARIAN MONITORING PRE/RECOOLING REFEER CONTAINER</h4>
	<br>
	
	<p>NOMOR CONTAINER</p>

	<table width="100%">
		<thead>
			<tr>
				<th rowspan="3">NO</th>
				<th rowspan="3">HARI / TANGGAL</th>
				<th rowspan="3">SET POINT</th>
				<th colspan="11" rowspan="2">TEMPERATURE RECORD</th>
				<th rowspan="2">PRE</th>
				<th rowspan="2">RE</th>
				<th colspan="4">CONTAINER</th>
			</tr>
			<tr>
				<th colspan="2">MASUK</th>
				<th colspan="2">KELUAR</th>
			</tr>
			<tr>
				<th>02.00</th>
				<th>04.00</th>
				<th>08.00</th>
				<th>10.00</th>
				<th>12.00</th>
				<th>14.00</th>
				<th>16.00</th>
				<th>18.00</th>
				<th>20.00</th>
				<th>22.00</th>
				<th>00.00</th>
				<th>(P)</th>
				<th>(R)</th>
				<th>TGL</th>
				<th>PKL</th>
				<th>TGL</th>
				<th>PKL</th>
			</tr>
		</thead>
		<tbody>
			<tr></tr>
		</tbody>
	</table>
</body>
</html>