<p>Kepada Yth.</p>
<p>{{ $data->customer_name }}</p>
<p>di tempat</p>
<br>
<p>Berikut kami lampirkan Daftar Pemakaian Alat Genset dan Penunjangnya Untuk Kegiatan Refeer Container di Lapangan {{ $data->field_name }} Periode tanggal {{ $data->start_date }} s.d tanggal {{ $data->end_date }}. Mohon untuk dilakukan pengecekan perihal lampiran tersebut.</p>
<br>
<p>Terimakasih.</p>