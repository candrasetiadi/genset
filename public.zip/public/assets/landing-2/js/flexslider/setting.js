
		$(window).load(function() {
			$('.flexslider').flexslider();
		});
