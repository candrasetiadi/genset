define( [
	"../../core"
], function( jQuery ) {
	"use strict";

	return jQuery.now();
} );
